import cors from "cors";
import { CronJob } from "cron";
import * as dotenv from "dotenv";
import ejs from "ejs";
import express from "express";
import session from "express-session";
import passport from "passport";
import path from "path";
import { fileURLToPath } from "url";
import { dbConnection } from "./src/config/Db.config.js";
import { cinemaSyncBatch, syncAllCinema } from "./src/controller/admin/DataSync.js";
import { downloadBookingTicketAsPDF } from "./src/controller/user/GeneralController.js";
import { router } from "./src/routes/AdminRoute.js";
import { commonRouter } from "./src/routes/CommonRoutes.js";
import { userRouter } from "./src/routes/UserRoute.js";
import {
  globalNotification,
  reminderNotification,
} from "./src/services/Notification.js";
import { removeCoupanJob } from "./src/services/vistaServices/promotionCoupan.js";
import { expireRewardsPoints } from "./src/services/ExpireRewardsJob.js";
import { ensureIndexes } from "./src/utils/dbIndexer.js";
import { razorpayRecoverPendingPayments } from "./src/services/razorpay/RazorpayCronJob.js";
const app = express();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
dbConnection();
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(function (req, res, next) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE");
  res.setHeader(
    "Access-Control-Allow-Headers",
    "Content-Type",
    "application/form-data",
    "multipart/form-data"
  );
  res.setHeader("Access-Control-Allow-Credentials", true);
  next();
});
app.use("/api/uploads", express.static("./public/uploads"));
app.use(
  session({
    secret: "secr3t",
    resave: false,
    saveUninitialized: true,
  })
);
app.use(passport.initialize());
app.use(passport.session());
app.use("/api/admin", router);
app.use("/api/user", userRouter);
app.use("/api", commonRouter);
app.set("views", __dirname + "/src/views");
app.engine("html", ejs.renderFile);
app.set("view engine", "ejs");
const isLoggedIn = (req, res, next) => {
  req.user ? next() : res.sendStatus(401);
};
app.get("/api/auth/google/success", isLoggedIn, (req, res) => {
  res.send({ user: req.user });
});
app.get("/t/:initTransId", async (req, res) => {
  if (req.url == "https://cnpx.in/") {
    res.redirect(
      "https://ticketing.theconnplex.com/booking-info?transId=" +
        req.url.replace("/", "")
    );
  } else {
    await downloadBookingTicketAsPDF(req, res);
  }
});
app.get("/:initTransId", async (req, res) => {
  if (req.url == "https://cnpx.in/") {
    res.redirect(
      "https://ticketing.theconnplex.com/booking-info?transId=" +
        req.url.replace("/", "")
    );
  } else {
    await downloadBookingTicketAsPDF(req, res);
  }
});

// const CinemaDataSyncJob = new CronJob(
//   //"30 */2 * * *", //In every 2:30 hours the cron job will run
//   // "    *",
//   "*/5 * * * *",
//   function () {

//     cinemaSyncBatch();

    
//   },
//   null,
//   true,
//   "Asia/Kolkata"
// );
// CinemaDataSyncJob.start();

// const globalNotificationCron = new CronJob(
//   "*/15 * * * *", // Every 10 minutes
//   function () {
//     globalNotification();
//   },
//   null,
//   true,
//   "Asia/Kolkata"
// );
// globalNotificationCron.start();

// const notificationCron = new CronJob(
//   "* * * * *",
//   function () {
//     reminderNotification();
//   },
//   null,
//   true,
//   "Asia/Kolkata"
// );
// notificationCron.start();

// const DataSyncJob = new CronJob(
//   // "30 */2 * * *",
//   "*/15 * * * *",
//   function () {},
//   null,
//   true,
//   "Asia/Kolkata"
// );
// DataSyncJob.start();
// //
// const coupanRemoveJob = new CronJob(
//   //"30 */2 * * *", //In every 2:30 hours the cron job will run
//   // "    *",
//   "*/18 * * * *", // Every 10 minutes
//   // '* * * * *', // Every 1 minute

//   function () {
//     removeCoupanJob();
//   },
//   null,
//   true,
//   "Asia/Kolkata"
// );
// coupanRemoveJob.start();

const expireRewardsJob = new CronJob(
  "0 0 * * *", // daily at midnight IST
  function () {
    expireRewardsPoints();
  },
  null,
  true,
  "Asia/Kolkata"
);
expireRewardsJob.start();

const razorpayRecoveryJob = new CronJob(
  "*/5 * * * *", // every 5 minutes
  function () {
    razorpayRecoverPendingPayments();
  },
  null,
  true,
  "Asia/Kolkata"
);
razorpayRecoveryJob.start();



const optimizedSync = new CronJob('*/15 * * * *', async () => {
  console.log('Running cinema sync job...');

  try {
    await ensureIndexes();
    await syncAllCinema();

    console.log('Cinema sync completed successfully');
  } catch (error) {
    console.error('Cinema sync failed:', error);
  }
} , null, true, 'Asia/Kolkata');


optimizedSync.start();



app.listen(process.env.PORT || 3020, "0.0.0.0", async () => {
  console.log("server is listen at " + process.env.PORT);
    // await ensureIndexes();
    // await syncAllCinema();

});
